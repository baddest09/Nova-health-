package com.flutter.doctoworld.doctoworld_doctor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
