class LoginInteractor {
  void loginWithMobile(String isoCode, String mobileNumber) {}
  void loginWithFacebook() {}
  void loginWithGoogle() {}
}
