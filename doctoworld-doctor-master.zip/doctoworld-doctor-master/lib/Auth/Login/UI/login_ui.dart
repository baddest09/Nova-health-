import 'package:animation_wrappers/animation_wrappers.dart';
// import 'package:buy_this_app/buy_this_app.dart';
import 'package:doctoworld_doctor/Components/custom_button.dart';
import 'package:doctoworld_doctor/Components/entry_field.dart';
import 'package:doctoworld_doctor/Locale/locale.dart';
import 'package:doctoworld_doctor/Theme/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../Config/app_config.dart';
import 'login_interactor.dart';

class LoginUI extends StatefulWidget {
  final LoginInteractor loginInteractor;

  LoginUI(this.loginInteractor);

  @override
  _LoginUIState createState() => _LoginUIState();
}

class _LoginUIState extends State<LoginUI> {
  final TextEditingController _numberController = TextEditingController();

  @override
  void dispose() {
    _numberController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _checkForBuyNow();
  }

  @override
  Widget build(BuildContext context) {
    var locale = AppLocalizations.of(context)!;
    var theme = Theme.of(context);
    var size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: theme.primaryColorLight,
      body: FadedSlideAnimation(
        SingleChildScrollView(
          child: Container(
            // height: size.height + 40,
            child: Stack(
              children: [
                Container(
                  width: MediaQuery.of(context).size.width,
                  height: size.height * 0.6,
                  color: theme.backgroundColor,
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 30),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Spacer(),
                      Expanded(
                          flex: 2,
                          child: Image.asset('assets/icons/doctor_logo.png')),
                      SizedBox(
                        height: 4,
                      ),
                      Text(
                        'Doctor App',
                        textAlign: TextAlign.center,
                        style: Theme.of(context)
                            .textTheme
                            .bodyText2!
                            .copyWith(color: Theme.of(context).primaryColor, fontSize: 14),
                      ),
                      Spacer(),
                      Expanded(
                          flex: 4, child: Image.asset('assets/hero_image.png')),
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(20.0),
                  child: Column(
                    children: [
                      SizedBox(height: size.height * 0.52),
                      EntryField(
                        hint: locale.enterMobileNumber,
                        prefixIcon: Icons.phone_iphone,
                        color: theme.scaffoldBackgroundColor,
                        controller: _numberController,
                      ),
                      SizedBox(height: 20.0),
                      CustomButton(
                          onTap: () => widget.loginInteractor
                              .loginWithMobile('', _numberController.text)),
                      SizedBox(
                        height: 70,
                      ),
                      Text(
                        locale.orQuickContinueWith!,
                        style: theme.textTheme.subtitle1,
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      Row(
                        children: [
                          Expanded(
                            child: Container(
                              decoration: BoxDecoration(
                                color: Color(0xff3c5a9a),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              padding: EdgeInsets.all(16.0),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Image.asset('assets/icons/ic_fb.png',
                                      scale: 2),
                                  SizedBox(width: 20),
                                  Expanded(
                                    child: Text(
                                      locale.facebook!,
                                      textAlign: TextAlign.center,
                                      overflow: TextOverflow.ellipsis,
                                      style: Theme.of(context)
                                          .textTheme
                                          .subtitle1!
                                          .copyWith(
                                              color: Colors.white,
                                              fontSize: 15),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          SizedBox(width: 20.0),
                          Expanded(
                            child: CustomButton(
                              label: locale.gmail,
                              icon: Image.asset(
                                'assets/icons/ic_ggl.png',
                                scale: 3,
                              ),
                              color: theme.scaffoldBackgroundColor,
                              textColor: theme.hintColor,
                              onTap: () =>
                                  widget.loginInteractor.loginWithGoogle(),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        beginOffset: Offset(0, 0.3),
        endOffset: Offset(0, 0),
        slideCurve: Curves.linearToEaseOut,
      ),
    );
  }

  void _checkForBuyNow() async {
    // SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    // if (!sharedPreferences.containsKey("key_buy_this_shown") &&
    //     AppConfig.isDemoMode) {
    //   Future.delayed(Duration(seconds: 10), () async {
    //     if (mounted) {
    //       BuyThisApp.showSubscribeDialog(context);
    //       sharedPreferences.setBool("key_buy_this_shown", true);
    //     }
    //   });
    // }
  }
}
